package Tutorial;

public interface IBehaviour {

    void movexy();
    void setx(int x);
    void sety(int y);
    int getx();
    int gety();
}
