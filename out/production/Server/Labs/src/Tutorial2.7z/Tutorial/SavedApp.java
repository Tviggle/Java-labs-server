package Tutorial;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

public class SavedApp implements Serializable {

    private static final long serialVersionUID = 1;

    private Vector houses;
    private HashSet<Integer> ids;
    private Map<Integer,Integer> borns;
    public SavedApp(Vector T,HashSet E,Map U)
    {
        houses=T;
        ids=E;
        borns=U;
    }
    public void Loading()
    {
        Habitat.houses=this.houses;
        Habitat.ids=this.ids;
        Habitat.borns=this.borns;
    }
}
