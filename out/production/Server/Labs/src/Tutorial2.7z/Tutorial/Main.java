package Tutorial;

public class Main {


    public static void main(String[] args) {
    Frame frm=new Frame();
    Starter go=new Starter();
    go.run();
    }
}